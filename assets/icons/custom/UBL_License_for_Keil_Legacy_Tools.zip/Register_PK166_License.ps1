﻿# Set Tool Installation Folder
$PK166_InstallationFolder = "C:\Keil_v5\"

# Set MDK Activation Code
$MDK_Activation_Code = "12345667-1234-1234-1234-123456788901"

# Set some Paths
$armlm_path     = Join-Path -Path $PK166_InstallationFolder -ChildPath "UV4\armlm\armlm.exe"
$KeilUtil_path  = Join-Path -Path $PK166_InstallationFolder -ChildPath "UV4\armlm\KeilUtil.exe"
$Tools_ini_path = Join-Path -Path $PK166_InstallationFolder -ChildPath "Tools.ini"

# Activate Keil MDK UBL License
& $armlm_path activate -code $MDK_Activation_Code
# Add Error Handling here

# Generate LIC License Codes for all older Products
$genLIC_Output = & $armlm_path genLIC

# Define the regex pattern for PK166 and capture the first match group
$regexPattern = "PK166:\s*(([A-Z0-9]{5}-?){6})"  # Example: "Error Code: (\d+)"
$matches = [regex]::Matches($genLIC_Output, $regexPattern)

# Check if any matches were found
if ($matches.Count -eq 1) {
    $PK166_LIC = $matches[0].Groups[1].Value
   
    # Use the PK166 LIC as a parameter for KeilUtil to register the License. It must run with administration rights!
    Write-Host "Found PK166 LIC: " $PK166_LIC
    $KeilUtil_Output = & $KeilUtil_path --installLicense $Tools_ini_path --lic $PK166_LIC
    Write-Host "Output of KeilUtil:" 
    Write-Host $KeilUtil_Output
}
else {   # No PK166 LIC was found
    Write-Host "Unexpected matches found in the armlm command output. Something went wrong. Here is the armlm genLIC output:"
    Write-Host $LIC_CommandOutput
}
